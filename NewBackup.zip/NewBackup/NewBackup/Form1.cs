﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.IO;
using System.Diagnostics;
using MySql.Data.MySqlClient;

namespace NewBackup
{
    public partial class Form1 : Form
    {

        // Variables for database
        MySqlConnection conn = new MySqlConnection("datasource=localhost;port=3306;username=root;password=;database=facerecognition_db");
        MySqlCommand cmd;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            InsertData();
        }

        public void InsertData()
        {
            MemoryStream ms = new MemoryStream();

          //  Bitmap image = TrainedFace.ToBitmap();

           // image.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);

           // byte[] img = ms.ToArray();
            //    pictureBox1.Image.Save(ms, pictureBox1.Image.RawFormat);

            String insertQuery = "INSERT INTO tbl_student_info(id, name, course, year, section) VALUES(@id, @name, @course, @year, @section)";

            conn.Open();
            cmd = new MySqlCommand(insertQuery, conn);

            cmd.Parameters.Add("@id", MySqlDbType.Int32, 11);
           // cmd.Parameters.Add("@img", MySqlDbType.Blob);
            cmd.Parameters.Add("@name", MySqlDbType.VarChar, 100);
            cmd.Parameters.Add("@course", MySqlDbType.VarChar, 100);
            cmd.Parameters.Add("@year", MySqlDbType.VarChar, 50);
            cmd.Parameters.Add("@section", MySqlDbType.VarChar, 100);

            //   cmd.Parameters["@id"].Value = 

           // cmd.Parameters["@img"].Value = img;
            cmd.Parameters["@name"].Value = textBox1.Text;
            cmd.Parameters["@course"].Value = textBox2.Text;
            cmd.Parameters["@year"].Value = textBox3.Text;
            cmd.Parameters["@section"].Value = textBox4.Text;

            if (cmd.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Data Inserted");
            }
            conn.Close();
        }
    }
}
