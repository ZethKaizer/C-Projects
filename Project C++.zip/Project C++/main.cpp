#include <iostream>
using namespace std;
//As default structuring nodes
struct node {
	int num;
	node *next; 
};

char selection(); //variable used to input character
bool empty(node *head); //variable used when the value is empty, the head returns true. else, it returns false
void saveAsFirstElement(node *&head, node *&last, int num);
void save(node*&head, node *&last, int num); //variable used to store data from 'void retrieve'
void retrieve(node *current);// variable used to show data

bool empty(node *head) //so this is how it works. just like what i've said from top, once the *head is empty, it returns true.

{
	if(head == NULL)
		return true;
	else
		return false;
	
}
char selection(){
	char choice;
	cout <<"WELCOME TO STUDENT INFORMATION SYSTEM! HOW CAN I HELP YOU? \n";
	cout <<"1. Add new student \n";
	cout <<"2. Show all student \n";
	cout <<"3. Exit \n";
	
	cin >> choice;
	return choice;
}
void saveAsFirstElement(node *&head, node *&last, int num) {
	node *temp = new node; //declaring variable 'temp' as new node.
	temp->num = num; //now temp is moved to num node
	temp->next = NULL; //this just means the last element of the linked list is just null
	//so, both of the code below, this just means the last element of the linked list is 'head' and 'last'. the variables declared inside parenthesis
	head = temp; 
	last = temp;
}

void save(node *&head, node *&last, int num) {
	
	
	if(empty(head)) //once the head is empty
		saveAsFirstElement(head, last, num); //it executes saveAsFirstElement, the variable used to input		
		else
		{
			node *temp = new node;
			temp->num = num;
			temp->next = NULL;
			last->next = temp;
			last = temp;
	}
}

void retrieve(node *current){
	if(empty(current))
	cout << "It seems the data is empty \n";
	else{
		cout<< "Students Information Record: \n";
		while(current !=NULL) 
		{
			cout << current->num <<endl;
			current = current->next;
		}
	}
}

int main() {
	node *head = NULL;
	node *last = NULL;
	char choice;
	int num;
	
	do{ 
	choice = selection();
		switch(choice){
			case '1': cout <<"Please input a number";
					  cin >> num;
					  save(head, last, num);
					  break;
			case '2': retrieve(head);
					  break;
			default: cout<<"System close \n";
		}
	}
	while(choice != '3');
}
